from django.apps import AppConfig


class LoginSysConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'login_sys'
