from django.contrib import admin

# Register your models here.
from login_sys.models import details
admin.site.register(details)